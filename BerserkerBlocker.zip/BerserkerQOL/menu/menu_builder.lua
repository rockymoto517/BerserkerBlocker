dofile(ModPath .. "lua/init.lua")
--Initialize the table

function berserkerQOL:json_encode(tab, path)
	local file = io.open(path, "w+")
	if file then
		file:write(json.encode(tab))
		file:close()
	end
end
	
function berserkerQOL:json_decode(tab, path)
	local file = io.open(path, "r")
	if file then
		for k, v in pairs(json.decode(file:read("*all")) or {}) do
			tab[k] = v
		end
		file:close()
	end
end

function berserkerQOL:Save()
	local path = self._data_path
	self:json_encode(self._data, path)
end

function berserkerQOL:Load()
	local path = self._data_path
	self:json_decode(self._data, path)
end

local save_exists = io.open(berserkerQOL._data_path, "r")
if save_exists ~= nil then
	save_exists:close()
	berserkerQOL:Load()
else
	berserkerQOL:Save()
end

Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_berserkerQOL", function( loc )
	loc:load_localization_file( berserkerQOL._path .. "menu/en.txt")
end)

Hooks:Add("MenuManagerInitialize", "MenuManagerInitialize_berserkerQOL", function( menu_manager )

	--Gather the options
	MenuCallbackHandler.berserkerQOL_callback_cc = function(self, item)
		berserkerQOL._data["cc_cancer"] = item:value()
		berserkerQOL:Save()
	end

	MenuCallbackHandler.berserkerQOL_callback_maniac = function(self, item)
		berserkerQOL._data["maniac_cancer"] = item:value()
		berserkerQOL:Save()
	end

	MenuCallbackHandler.berserkerQOL_callback_hacker = function(self, item)
		berserkerQOL._data["hacker_cancer"] = item:value()
		berserkerQOL:Save()
	end

	MenuCallbackHandler.berserkerQOL_callback_tt = function(self, item)
		berserkerQOL._data["tt_cancer"] = item:value()
		berserkerQOL:Save()
	end
	berserkerQOL:Load()
	MenuHelper:LoadFromJsonFile(berserkerQOL._path .. "menu/options.json", berserkerQOL, berserkerQOL._data)

end)